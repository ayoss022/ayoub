package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
/**
 * Controller-Klasse für die Ansicht der gespeicherten Informationen.
 */

public class SavedInfoController {
    @FXML
    private TableView<Info> infoTable;

    @FXML
    private TableColumn<Info, String> nachnameColumn;

    @FXML
    private TableColumn<Info, String> vornameColumn;

    @FXML
    private TableColumn<Info, Float> calorieNeedsColumn;

    // Felder für die primäre Stage und die vorherige Szene
    private Stage primaryStage;
    private Scene previousScene;

    // ObservableList zum Speichern der Informationen
    private ObservableList<Info> infoData = FXCollections.observableArrayList();

    // Referenz auf KalorieBedarfController
    private KalorieBedarfController kalorieBedarfController;  // Reference to KalorieBedarfController

    // Initialisierungsmethode, die beim Laden der Szene aufgerufen wird

    /**
     * Initialisierungsmethode, die beim Laden der Szene aufgerufen wird.
     * Setzt die Spaltenfabriken und die TableView-Datenquelle.
     */
    @FXML
    private void initialize() {
        // Setzt die Zellwertfabrik für jede Spalte, um die entsprechenden Daten aus der Info-Klasse anzuzeigen
        nachnameColumn.setCellValueFactory(new PropertyValueFactory<>("nachname"));
        vornameColumn.setCellValueFactory(new PropertyValueFactory<>("vorname"));
        calorieNeedsColumn.setCellValueFactory(new PropertyValueFactory<>("calorieNeeds"));

        // Setzt die Elemente der TableView auf die ObservableList
        infoTable.setItems(infoData);
    }
    // Methode zum Setzen der primären Stage
    /**
     * Setzt die primäre Stage für diesen Controller.
     *
     * @param primaryStage Die primäre Stage der Anwendung.
     */
    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    // Methode zum Setzen der vorherigen Szene
    /**
     * Setzt die vorherige Szene für die Rückkehr zur Hauptansicht.
     *
     * @param previousScene Die vorherige Szene vor dem Anzeigen dieser Szene.
     */
    public void setPreviousScene(Scene previousScene) {
        this.previousScene = previousScene;
    }

    // Methode zum Hinzufügen eines Info-Objekts zur ObservableList
    /**
     * Fügt ein Info-Objekt zur ObservableList hinzu und aktualisiert die TableView.
     *
     * @param info Das Info-Objekt, das hinzugefügt werden soll.
     */
    public void addInfoItem(Info info) {
        infoData.add(info);
    }

    // Methode zum Löschen aller Info-Objekte aus der ObservableList
    /**
     * Löscht alle Info-Objekte aus der ObservableList und aktualisiert die TableView.
     */
    public void clearInfoItems() {
        infoData.clear();
    }

    // Methode zum Setzen des KalorieBedarfControllers
    /**
     * Setzt die Referenz auf den KalorieBedarfController für die Kommunikation.
     *
     * @param kalorieBedarfController Der KalorieBedarfController, der Referenziert werden soll.
     */
    public void setKalorieBedarfController(KalorieBedarfController kalorieBedarfController) {
        this.kalorieBedarfController = kalorieBedarfController;
    }

    // Methode zum Löschen des ausgewählten Info-Objekts
    /**
     * Behandelt das Zurückkehren zur vorherigen Szene (Hauptszene).
     */
    @FXML
    private void handleBack() {
        if (previousScene != null) {
            primaryStage.setScene(previousScene);
        }
    }
    /**
     * Behandelt das Löschen des ausgewählten Info-Objekts aus der TableView und der gespeicherten Liste.
     * Zeigt eine Warnung an, wenn kein Objekt ausgewählt ist.
     */
    @FXML
    private void handleDelete() {
        Info selectedInfo = infoTable.getSelectionModel().getSelectedItem();
        if (selectedInfo != null) {
            infoData.remove(selectedInfo);
            if (kalorieBedarfController != null) {
                kalorieBedarfController.removeInfo(selectedInfo);
            }
        } else {
            // Warnung anzeigen, wenn keine Zeile zum Löschen ausgewählt wurde
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warnung");
            alert.setHeaderText(null);
            alert.setContentText("Bitte wählen Sie eine Zeile zum Löschen aus.");
            alert.showAndWait();
        }
    }

    // Methode zum Bearbeiten des ausgewählten Info-Objekts

    /**
     * Behandelt das Bearbeiten des ausgewählten Info-Objekts.
     * Lädt die Informationen in die Eingabefelder des KalorieBedarfControllers,
     * entfernt das alte Info-Objekt aus der Liste und navigiert zur Hauptszene.
     * Zeigt eine Warnung an, wenn kein Objekt ausgewählt ist.
     */
    @FXML
    private void handleEdit() {
        Info selectedInfo = infoTable.getSelectionModel().getSelectedItem();
        if (selectedInfo != null) {
            // Laden der Informationen in die Eingabefelder des KalorieBedarfControllers
            kalorieBedarfController.loadInfoToFields(selectedInfo);

            // Entfernen der alten Info aus der Liste
            infoData.remove(selectedInfo);
            kalorieBedarfController.removeInfo(selectedInfo);

            // Zurückkehren zur Hauptszene zum Bearbeiten
            if (previousScene != null) {
                primaryStage.setScene(previousScene);
            }
        } else {
            // Warnung anzeigen, wenn keine Zeile zum Bearbeiten ausgewählt wurde
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warnung");
            alert.setHeaderText(null);
            alert.setContentText("Bitte wählen Sie eine Zeile zum Bearbeiten aus.");
            alert.showAndWait();
        }
    }
}



