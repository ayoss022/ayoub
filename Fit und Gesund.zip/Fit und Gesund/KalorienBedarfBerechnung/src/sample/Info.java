package sample;


/**
 * Diese Klasse repräsentiert Informationen über eine Person, einschließlich Nachname, Vorname und Kalorienbedarf.
 */

public class Info {
    private String nachname;
    private String vorname;
    private float calorieNeeds;

    /**
     * Konstruktor, um eine neue Instanz der Info-Klasse zu erstellen.
     *
     * @param nachname     Der Nachname der Person.
     * @param vorname      Der Vorname der Person.
     * @param calorieNeeds Der Kalorienbedarf der Person.
     */
    public Info(String nachname, String vorname, float calorieNeeds) {
        this.nachname = nachname;
        this.vorname = vorname;
        this.calorieNeeds = calorieNeeds;
    }

    /**
     * Gibt den Nachnamen der Person zurück.
     *
     * @return Der Nachname der Person.
     */
    public String getNachname() {
        return nachname;
    }

    /**
     * Gibt den Vornamen der Person zurück.
     *
     * @return Der Vorname der Person.
     */
    public String getVorname() {
        return vorname;
    }

    /**
     * Gibt den Kalorienbedarf der Person zurück.
     *
     * @return Der Kalorienbedarf der Person.
     */
    public float getCalorieNeeds() {
        return calorieNeeds;
    }

    /**
     * Überschriebene Methode zur Erstellung einer String-Repräsentation der Info.
     *
     * @return Eine String-Repräsentation der Form "Nachname: ..., Vorname: ..., Kalorienbedarf: ...".
     */
    @Override
    public String toString() {
        return "Nachname: " + nachname + ", Vorname: " + vorname + ", Kalorienbedarf: " + calorieNeeds;
    }
}
