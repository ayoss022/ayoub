package sample;

public class ExeMain {
    public static void main(String[] args){
        Main.main(args);
    }
}
