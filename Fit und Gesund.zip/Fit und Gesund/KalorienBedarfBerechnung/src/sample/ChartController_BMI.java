package sample;

import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;

import java.util.List;
/**
 * Controller-Klasse für das BMI-Diagramm, das BMI-Informationen visualisiert.
 */
public class ChartController_BMI {
    @FXML
    private BarChart<String, Number> BarChart;

    private List<Info_BMI> savedInfoList;

    /**
     * Setzt die Liste der gespeicherten BMI-Informationen und initialisiert das Diagramm.
     *
     * @param savedInfoList Die Liste der gespeicherten BMI-Informationen.
     */
    public void setSavedInfoList(List<Info_BMI> savedInfoList) {
        this.savedInfoList = savedInfoList;
        initializeChart();
    }

    /**
     * Private Methode zur Initialisierung des BMI-Diagramms.
     * Es erstellt eine Serie basierend auf den gespeicherten BMI-Informationen.
     */
    private void initializeChart() {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        for (Info_BMI info : savedInfoList) {
            series.getData().add(new XYChart.Data<>(info.getVorname() + " " + info.getNachname(), info.getBMI()));
        }

        // Serie zum Diagramm hinzufügen
        BarChart.getData().add(series);
    }
}

