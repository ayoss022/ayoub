package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        // FXMLLoader initialisieren und FXML-Datei laden
        FXMLLoader loader = new FXMLLoader(getClass().getResource("StartseiteView.fxml"));
        Parent root = loader.load();

        // Controller-Instanz aus dem FXMLLoader erhalten
        StartseiteController controller = loader.getController();
        // Primärstage an den Controller übergeben
        controller.setPrimaryStage(primaryStage);

        // Primärstage konfigurieren
        primaryStage.setTitle("Fit & Gesund"); // Titel der Anwendung setzen
        Scene scene = new Scene(root, 800, 600); // Szene mit Root-Node und Größe erstellen
        primaryStage.setScene(scene); // Szene zur Primärstage hinzufügen
        primaryStage.show(); // Primärstage anzeigen
    }

    public static void main(String[] args) {
        launch(args);
    }
}