package sample;


/**
 * Die BMIModel-Klasse repräsentiert das Modell für die BMI-Berechnung.
 */

public class BMIModel {
    private float gewicht;
    private float groesse;

    /**
     * Setzt die Größe für die BMI-Berechnung.
     *
     * @param groesse Die Größe der Person in Metern.
     */

    public void setGroesse(float groesse) {//set-Methode um den Zustand eines Objekts zu aktualisieren.

        this.groesse = groesse;/*Die Methode erhält einen Parameter groesse vom Typ float, der den neuen Wert für die Instanzvariable groesse darstellt
        wir setzen die Instanzvariable groesse auf dem Wert,der die Methode setGroesse übergeben wurde. */
    }

    /**
     * Setzt das Gewicht für die BMI-Berechnung.
     *
     * @param gewicht Das Gewicht der Person in Kilogramm.
     */

    public void setGewicht(float gewicht) {

        this.gewicht = gewicht;
    }
    /**
     * Gibt die gesetzte Größe zurück.
     *
     * @return Die Größe der Person in Metern.
     */

    public float getGroesse() {
        return groesse;
    }


    /**
     * Gibt das gesetzte Gewicht zurück.
     *
     * @return Das Gewicht der Person in Kilogramm.
     */

    public float getGewicht() {
        return gewicht;
    }


    /**
     * Berechnet den BMI (Body Mass Index) basierend auf dem gesetzten Gewicht und der Größe.
     *
     * @return Der berechnete BMI der Person.
     */

    public float calculateBMI(){
        float bmi ;/*Body Mass Index,Ein Mensch gilt als übergewichtig (adipös), wenn sein Body-Mass-Index (BMI) über 30 liegt.
        Der BMI wird oft verwendet, um den Grad der Adipositas (Fettleibigkeit) oder Untergewichts bei Menschen einzuschätzen.
        Die Interpretation des BMI basiert auf den folgenden Kategorien, die von der Weltgesundheitsorganisation (WHO) definiert wurden:

Untergewicht: BMI unter 18,5
Normalgewicht: BMI zwischen 18,5 und 24,9
Übergewicht: BMI zwischen 25 und 29,9
Adipositas (Fettleibigkeit) Klasse I: BMI zwischen 30 und 34,9
Adipositas Klasse II: BMI zwischen 35 und 39,9
Adipositas Klasse III (schwere Adipositas): BMI 40 und höher
        */
        bmi= gewicht / (groesse * groesse);
        return bmi;
    }
}

