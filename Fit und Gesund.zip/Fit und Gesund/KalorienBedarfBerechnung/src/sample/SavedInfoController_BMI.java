package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class SavedInfoController_BMI {
    /**
     * Controller-Klasse für die Ansicht der gespeicherten BMI-Informationen.
     */
    // FXML-Felder, die die GUI-Komponenten repräsentieren
    @FXML
    private TableView<Info_BMI> infoTable; // TableView ist eine generische Klasse in JavaFX, der generische Typ <Info_BMI> bedeutet, dass diese TableView speziell für Objekte vom Typ Info_BMI vorgesehen ist.

    @FXML
    private TableColumn<Info_BMI, String> nachnameColumn; // Spalte zur Darstellung des Nachnamens eines Info_BMI Objekts. Der generische Typ <Info_BMI, String> bedeutet, dass diese Spalte speziell für Objekte vom Typ Info_BMI und in der Werte vom Typ String vorgesehen ist.

    @FXML
    private TableColumn<Info_BMI, String> vornameColumn; // Spalte zur Darstellung des Vornamens eines Info_BMI Objekts.

    @FXML
    private TableColumn<Info_BMI, Float> BMIColumn; // Spalte zur Darstellung des BMI-Wertes eines Info_BMI Objekts.



    // Private Felder
    private Stage primaryStage; // Die Hauptbühne der Anwendung
    private Scene previousScene; // Die vorherige Szene, zu der zurückgekehrt werden kann
    private BMIController bmiController; // Referenz auf den BMIController
    private ObservableList<Info_BMI> infoData = FXCollections.observableArrayList(); // ObservableList zum Speichern der Informationen

    // Initialisierungsmethode, die beim Laden der Szene aufgerufen wird
    /**
     * Initialisierungsmethode, die beim Laden der Szene aufgerufen wird.
     * Setzt die Spaltenfabriken und die TableView-Datenquelle.
     */
    @FXML
    private void initialize() {
        // Setzt die Zellwertfabrik für jede Spalte, um die entsprechenden Daten aus der Info_BMI-Klasse anzuzeigen
        nachnameColumn.setCellValueFactory(new PropertyValueFactory<>("nachname"));
        vornameColumn.setCellValueFactory(new PropertyValueFactory<>("vorname"));
        BMIColumn.setCellValueFactory(new PropertyValueFactory<>("BMI"));

        // Setzt die Elemente der TableView auf die ObservableList
        infoTable.setItems(infoData);
    }

    // Methode zum Setzen der primären Stage
    /**
     * Setzt die primäre Stage für diesen Controller.
     *
     * @param primaryStage Die primäre Stage der Anwendung.
     */
    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    // Methode zum Setzen der vorherigen Szene
    /**
     * Setzt die vorherige Szene für die Rückkehr zur Hauptansicht.
     *
     * @param previousScene Die vorherige Szene vor dem Anzeigen dieser Szene.
     */
    public void setPreviousScene(Scene previousScene) {
        this.previousScene = previousScene;
    }

    // Methode zum Hinzufügen eines Info_BMI-Objekts zur ObservableList
    /**
     * Fügt ein Info_BMI-Objekt zur ObservableList hinzu und aktualisiert die TableView.
     *
     * @param info Das Info_BMI-Objekt, das hinzugefügt werden soll.
     */
    public void addInfoItem(Info_BMI info) {
        infoData.add(info);
    }

    // Methode zum Löschen aller Info_BMI-Objekte aus der ObservableList
    /**
     * Löscht alle Info_BMI-Objekte aus der ObservableList und aktualisiert die TableView.
     */
    public void clearInfoItems() {
        infoData.clear();
    }

    // Methode zum Setzen des BMIControllers
    /**
     * Setzt die Referenz auf den BMIController für die Kommunikation.
     *
     * @param bmiController Der BMIController, der Referenziert werden soll.
     */
    public void setBMIBedarfController(BMIController bmiController) {
        this.bmiController = bmiController;
    }

    // Methode zum Zurückkehren zur vorherigen Szene

    /**
     * Behandelt das Zurückkehren zur vorherigen Szene (Hauptszene).
     */
    @FXML
    private void handleBack() {
        if (previousScene != null) {
            primaryStage.setScene(previousScene);
        }
    }

    // Methode zum Löschen des ausgewählten Info_BMI-Objekts
    /**
     * Behandelt das Löschen des ausgewählten Info_BMI-Objekts aus der TableView und der gespeicherten Liste.
     * Zeigt eine Warnung an, wenn kein Objekt ausgewählt ist.
     */
    @FXML
    private void handleDelete() {
        Info_BMI selectedInfo = infoTable.getSelectionModel().getSelectedItem();
        if (selectedInfo != null) {
            infoData.remove(selectedInfo);
            if (bmiController != null) {
                bmiController.removeInfo_BMI(selectedInfo);
            }
        } else {
            // Warnung anzeigen, wenn keine Zeile zum Löschen ausgewählt wurde
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warnung");
            alert.setHeaderText(null);
            alert.setContentText("Bitte wählen Sie eine Zeile zum Löschen aus.");
            alert.showAndWait();
        }
    }

    // Methode zum Bearbeiten des ausgewählten Info_BMI-Objekts
    /**
     * Behandelt das Bearbeiten des ausgewählten Info_BMI-Objekts.
     * Lädt die Informationen in die Eingabefelder des BMIControllers,
     * entfernt das alte Info_BMI-Objekt aus der Liste und navigiert zur Hauptszene.
     * Zeigt eine Warnung an, wenn kein Objekt ausgewählt ist.
     */
    @FXML
    private void handleEdit() {
        Info_BMI selectedInfo = infoTable.getSelectionModel().getSelectedItem();
        if (selectedInfo != null) {
            // Laden der Informationen in die Eingabefelder des BMIControllers
            bmiController.loadInfoToFields(selectedInfo);

            // Entfernen der alten Info aus der Liste
            infoData.remove(selectedInfo);
            bmiController.removeInfo_BMI(selectedInfo);

            // Zurückkehren zur Hauptszene zum Bearbeiten
            if (previousScene != null) {
                primaryStage.setScene(previousScene);
            }
        } else {
            // Warnung anzeigen, wenn keine Zeile zum Bearbeiten ausgewählt wurde
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warnung");
            alert.setHeaderText(null);
            alert.setContentText("Bitte wählen Sie eine Zeile zum Bearbeiten aus.");
            alert.showAndWait();
        }
    }
}
