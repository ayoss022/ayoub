package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Controller-Klasse für die BMI-Berechnung und -Verwaltung.
 */
public class BMIController {/* Die BMIController-Klasse ist der Controller für die Anwendung, die die Berechnung und Verwaltung des Body Mass Index (BMI) sowie die Interaktion mit der Benutzeroberfläche steuert*/
    //View:
    //
    //Stellt die Benutzeroberfläche dar.
    //Ist für die Darstellung der Daten verantwortlich.
    //Enthält keine Geschäftslogik.
    //Controller:
    //
    //Verarbeitet Benutzereingaben.
    //Verknüpft die View mit dem Model.
    //Enthält die Geschäftslogik und Steuerungslogik.
    //Model:
    //
    //Stellt die Daten und die Geschäftslogik dar.
    //Ist unabhängig von der Benutzeroberfläche
    @FXML
    private TextField gewichtInputField;//Die @FXML Annotationen markieren die Instanzvariablen, die auf GUI-Elemente in der zugehörigen FXML-Datei verweisen.

    @FXML
    private TextField groesseInputField;
    @FXML
    private TextField nachnameInputField;
    @FXML
    private TextField vornameInputField;
    @FXML
    private Label bmiOutputLABEL    ;
    /*
   gewichtInputField, groesseInputField, nachnameInputField, vornameInputField: Diese TextField-Elemente verweisen auf die Eingabefelder für Gewicht, Größe, Nachname und Vorname der Benutzerdaten*/
    private BMIModel bmiModel = new BMIModel();/*private unterstützt das Prinzip der Datenkapselung
    bmiModel: Eine Instanz der Klasse BMIModel, die für die Berechnung des BMI verwendet wird. Diese Instanz wird initialisiert, um die Methoden zur Einstellung von Gewicht (setGewicht) und Größe (setGroesse) sowie zur Berechnung des BMI (calculateBMI) zu nutzen
    */
//Der Controller ist dafür zuständig, auf Benutzereingaben (z.B. Mausklicks, Tastatureingaben) zu reagieren. Wenn ein Benutzer z.B. auf einen Button klickt, muss der Controller wissen, welche Aktion ausgeführt werden soll.
// Die Verbindung zwischen View und Controller ermöglicht es, diese Interaktionen zu handhaben
    private List<Info_BMI> savedInfoList = new ArrayList<>();/*savedInfoList: Eine Liste von Info_BMI-Objekten, die verwendet wird, um bereits gespeicherte BMI-Informationen zu halten.
     Neue Informationen werden hier hinzugefügt, wenn sie erfolgreich validiert wurden und nicht dupliziert sind.
      Instanziierung: new ArrayList<>() erstellt eine neue ArrayList, die als Speicher für die Info_BMI-Objekte verwendet wird.
       Eine ArrayList ist eine dynamische Liste in Java, die Elemente hinzufügen, entfernen und durchlaufen kann
       Wenn Sie nur die allgemeine Funktionalität einer Liste benötigen und flexibel bleiben möchten, verwenden Sie List<> als Typ für Ihre Variablen oder Methodenparameter.
Wenn Sie spezifische Eigenschaften einer ArrayList benötigen, wie schnellen Zugriff und dynamisches Wachstum, instanziieren Sie ArrayList<>.
also die variable savedInfoList ist eine Liste,die alle Elemente der Klasse Info_BMI speichern kann.
Diese Variable wird dann spezifisch als ArrayListe deklariert.Diese Liste bietet den Vorteil des automatischen Wachstums */

/*Wenn sich Daten im Model ändern (z.B. das Ergebnis einer Berechnung), muss die Benutzeroberfläche entsprechend aktualisiert werden.
 Der Controller empfängt diese Änderungen und sorgt dafür, dass die View die aktuellen Daten anzeigt*/
    private Stage primaryStage;/* primaryStage: Die Hauptbühne der Anwendung, die gesetzt wird, um zwischen verschiedenen Szenen (Ansichten) zu navigieren.
    Diese Variable wird durch die Methode setPrimaryStage gesetzt.*/


    /**
     * Methode zum Setzen des Hauptfensters.
     *
     * @param primaryStage Die Hauptbühne der Anwendung.
     */

    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    /**
     * Event-Handler für die Berechnung des BMI.
     * Versucht, den BMI basierend auf den eingegebenen Werten zu berechnen und anzuzeigen.
     * Zeigt eine Warnung an, wenn ungültige Eingaben gemacht werden.
     */
    @FXML
    private void handleBMIBerechnung() {
        try {
            float gewicht = Float.parseFloat(gewichtInputField.getText());
           float groesse = Float.parseFloat(groesseInputField.getText()) ;
        /* Das try-catch-Block in der Methode handleBMIBerechnung() dient dazu, potenzielle Fehler abzufangen, die während der Berechnung des BMI auftreten könnten.*/
            /* Der try-Block enthält den Code, der möglicherweise eine Ausnahme (Exception) auslösen könnte.
        In diesem Fall versucht die Methode, das Gewicht und die Größe aus den Textfeldern gewichtInputField und groesseInputField zu lesen und dann den BMI zu berechnen.*/
            /* Float.parseFloat(...): Konvertiert die eingelesenen Textwerte (die als Zeichenketten vorliegen) in Fließkommazahlen (float).
            Diese Konvertierung kann eine NumberFormatException auslösen, wenn der Textwert nicht in eine gültige Fließkommazahl umgewandelt werden kann (z.B. wenn der Benutzer Buchstaben statt Zahlen eingibt).*/
            bmiModel.setGewicht(gewicht);
            bmiModel.setGroesse(groesse);

         double bmi=bmiModel.calculateBMI();
          bmiOutputLABEL.setText(String.format("%.2f", bmi));
        } catch (NumberFormatException e) {
            bmiOutputLABEL.setText("Ungültige Eingabe");
        }
    }

    /**
     * Event-Handler zum Speichern der BMI-Informationen.
     * Validiert die Eingaben und speichert die Informationen, wenn sie gültig sind und noch nicht gespeichert wurden.
     * Zeigt eine Warnung an, wenn Felder nicht ausgefüllt sind oder wenn die Informationen bereits vorhanden sind.
     *
     * @param actionEvent Das ausgelöste Ereignis.
     */

    @FXML
    private void handleSave(ActionEvent actionEvent) {
        String nachname = nachnameInputField.getText();
        String vorname = vornameInputField.getText();
        String groesse = groesseInputField.getText();
        String gewicht = gewichtInputField.getText();
        /*Die Methode beginnt damit, die aktuellen Texte aus den Eingabefeldern nachnameInputField, vornameInputField, groesseInputField und gewichtInputField zu lesen.
        */

     // Überprüfen, ob alle Felder ausgefüllt sind


        if (nachname.isEmpty() || vorname.isEmpty()
               || groesse.isEmpty() || gewicht.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warnung");

            alert.setContentText("Keine Infos sind gespeichert. Bitte füllen Sie alle Felder aus.");
            alert.showAndWait();
            return;//wenn die Bedingung erfüllt ist,dann kehrt die ohne weitere Aktionen zurück.
        }

        try {
           float bmi = bmiModel.calculateBMI();
            Info_BMI info= new Info_BMI(nachname, vorname, bmi);

            if (!isInfoDuplicate(info)) {
                savedInfoList.add(info);
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("SavedInfoView_BMI.fxml"));/*Wenn die Info_BMI nicht dupliziert ist, wird die Liste savedInfoList aktualisiert und die Benutzeroberfläche für die Anzeige der gespeicherten Informationen vorbereitet.
                     Dazu wird die FXML-Datei SavedInfoView_BMI.fxml geladen und ein neuer Controller SavedInfoController_BMI instanziiert, um die Anzeige zu steuern
                     Diese FXML-Datei beschreibt die Struktur und das Layout der Benutzeroberfläche.*/
                    Parent root = loader.load();//Parent ist die Basis-Klasse für alle Layout-Panes (wie VBox, HBox, GridPane usw.).
                    // Die root-Variable enthält die Wurzel des geladenen Szenengraphen. Das heißt, es repräsentiert das oberste Element des Layouts, das in der FXML-Datei definiert ist.Im Beispiel BMIView ist die Wurzelknote:VBox.
                    //loader.load() liest die FXML-Datei und erstellt eine Instanz der VBox, die alle darin definierten UI-Komponenten enthält.Parent root speichert diese VBox-Instanz, die der Wurzelknoten des Szenengraphen ist.

                    SavedInfoController_BMI savedInfoController_bmi = loader.getController();//Diese Methode wird verwendet, um den Controller zu erhalten, der mit der FXML-Datei verbunden ist.
                    //Beispiel in der FXML-Datei: fx:controller="sample.SavedInfoController_BMI"
                    //Der Controller wird einer Variablen vom Typ SavedInfoController_BMI zugewiesen
                    //Dies ermöglicht es, auf die Methoden und Felder des Controllers zuzugreifen, um weitere Konfigurationen vorzunehmen
                    savedInfoController_bmi.setPrimaryStage(primaryStage);//das Hauptfenster bleibt hier dasselbe wie bei BMI-View,aber die Sczene verändert
                    /*Ihre Anwendung verwendet die Hauptbühne (primaryStage) konsistent über verschiedene Szenen hinweg. Wenn Sie auf den "Speichern"-Button im BMI-Rechner klicken, wird eine neue Szene (SavedInfoView_BMI.fxml) auf derselben Hauptbühne angezeigt.
                     Dies ermöglicht eine nahtlose Navigation innerhalb der Anwendung, ohne dass die Hauptbühne neu initialisiert werden muss.*/
                    savedInfoController_bmi.setPreviousScene(primaryStage.getScene());
                    //Die Methode setPreviousScene im SavedInfoController_BMI nimmt die vorherige Scene (also die Szene, die vor dem Wechsel zu SavedInfoView_BMI.fxml aktiv war) als Parameter.
                    // Dies ermöglicht es dem SavedInfoController_BMI, auf die vorherige Szene zuzugreifen und bei Bedarf dorthin zurückzukehren
                    savedInfoController_bmi.setBMIBedarfController(this);


                    savedInfoController_bmi.clearInfoItems();//Wenn Sie neue Informationen in der SavedInfoController_BMI-Ansicht anzeigen möchten, müssen Sie sicherstellen, dass alle vorherigen Informationen entfernt wurden. Andernfalls könnten alte oder veraltete Informationen im UI bleiben, was zu einer inkonsistenten Benutzererfahrung führen könnte.
                    // Indem Sie clearInfoItems() aufrufen, stellen Sie sicher, dass das UI bereit ist, die aktuellen und korrekten Informationen anzuzeigen
                    for (Info_BMI savedInfo : savedInfoList) {//for-each loop
                        savedInfoController_bmi.addInfoItem(savedInfo);//Diese Schleife bietet eine einfache Möglichkeit, über Elemente einer Collection oder eines Arrays zu iterieren, ohne explizit den Index zu verwenden
                        /*
                        * In Ihrem spezifischen Beispiel iteriert die Schleife über jedes Info_BMI-Objekt in der savedInfoList.
Für jedes Info_BMI-Objekt wird die Methode addInfoItem(savedInfo) des savedInfoController_bmi aufgerufen.
Dies bedeutet, dass jedes Info_BMI-Objekt der savedInfoList dem savedInfoController_bmi hinzugefügt wird, normalerweise für die Anzeige oder Verarbeitung in der Benutzeroberfläche*/
                    }

                    Scene scene = new Scene(root, 800, 600);
                    primaryStage.setScene(scene);
                } catch (IOException e) {
                    e.printStackTrace();/* Dies kann eine NumberFormatException auslösen, wenn ungültige Zeichen (z.B. Buchstaben statt Zahlen) in den Eingabefeldern für Gewicht oder Größe stehen*/
                }
            } else {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setHeaderText(null);
                alert.setContentText("Diese Informationen sind bereits gespeichert.");
                alert.show();
            }
        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warnung");
            alert.setHeaderText(null);
            alert.setContentText("Bitte geben Sie gültige Werte für alle Felder ein.");
            alert.show();
        }
    }

    /**
     * Methode zur Überprüfung, ob eine Info bereits gespeichert ist.
     *
     * @param info Die zu überprüfende Info.
     * @return true, wenn die Info bereits gespeichert ist; false sonst.
     */

    private boolean isInfoDuplicate(Info_BMI info) {//Die Methode isInfoDuplicate(Info_BMI info) in Ihrem Code dient dazu, zu überprüfen, ob eine bestimmte Info_BMI-Instanz bereits in der Liste savedInfoList vorhanden ist.
        /*
         Innerhalb der Schleife wird für jedes savedInfo-Objekt überprüft, ob die Nachnamen, Vornamen und der BMI-Wert mit den entsprechenden Werten der übergebenen info übereinstimmen.
Wenn alle Bedingungen erfüllt sind (d. h. Nachname, Vorname und BMI sind identisch), gibt die Methode true zurück, was bedeutet, dass die info bereits in der Liste savedInfoList vorhanden ist und als dupliziert betrachtet wird.
Wenn ein solches Duplikat gefunden wird, wird die Methode sofort mit return true; beendet und gibt true zurück*/
        for (Info_BMI savedInfo : savedInfoList) {
            if (savedInfo.getNachname().equals(info.getNachname())
                    && savedInfo.getVorname().equals(info.getVorname())
                    && savedInfo.getBMI() == info.getBMI()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Methode zum Entfernen einer BMI-Information aus der Liste.
     *
     * @param info Die zu entfernende BMI-Information.
     */

    public void removeInfo_BMI(Info_BMI info) {
        savedInfoList.remove(info);
    }

    /**
     * Methode zum Laden von BMI-Informationen in die Eingabefelder.
     *
     * @param info Die BMI-Informationen, die geladen werden sollen.
     */

    public void loadInfoToFields(Info_BMI info) {
        nachnameInputField.setText(info.getNachname());
        vornameInputField.setText(info.getVorname());
        groesseInputField.setText(String.valueOf(bmiModel.getGroesse()));
        gewichtInputField.setText(String.valueOf(bmiModel.getGewicht()));
    }

    /**
     * Event-Handler zum Zurückkehren zur Startseite.
     *
     * @throws Exception wenn ein Fehler beim Laden der Startseitenansicht auftritt.
     */

    @FXML
    private void handleBack() throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("StartseiteView.fxml"));
        Parent root = loader.load();

        StartseiteController controller = loader.getController();
        controller.setPrimaryStage(primaryStage);

        Scene scene = new Scene(root,800,600);
        primaryStage.setScene(scene);
    }

    /**
     * Event-Handler zum Anzeigen des BMI-Diagramms.
     * Lädt das Diagramm und zeigt es in einem neuen Fenster an.
     *
     * @throws IOException wenn ein Fehler beim Laden der ChartView_BMI.fxml auftritt.
     */

    @FXML
    private void handleShowChart() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ChartView_BMI.fxml"));
        Parent root = loader.load();

        ChartController_BMI chartController_bmi = loader.getController();
        chartController_bmi.setSavedInfoList(savedInfoList);

        Stage stage = new Stage();
        stage.setTitle("BMI Diagramm");
        stage.setScene(new Scene(root, 800, 600));
        stage.show();
    }
}