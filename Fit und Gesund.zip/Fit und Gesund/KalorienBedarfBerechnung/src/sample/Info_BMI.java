package sample;


/**
 * Diese Klasse repräsentiert Informationen über eine Person, einschließlich Nachname, Vorname und BMI.
 * <p>
 * <span style="color: blue;">public class Info_BMI {</span>
 */
public class Info_BMI {
    private String nachname;
    private String vorname;
    private float BMI;

    /**
     * Konstruktor, um eine neue Instanz der Info_BMI-Klasse zu erstellen.
     *
     * @param nachname Der Nachname der Person.
     * @param vorname  Der Vorname der Person.
     * @param BMI      Der BMI (Body-Mass-Index) der Person.
     */
    public Info_BMI(String nachname, String vorname, float BMI) {
        this.nachname = nachname;
        this.vorname = vorname;
        this.BMI = BMI;
    }

    /**
     * Gibt den Nachnamen der Person zurück.
     *
     * @return Der Nachname der Person.
     */
    public String getNachname() {
        return nachname;
    }

    /**
     * Gibt den Vornamen der Person zurück.
     *
     * @return Der Vorname der Person.
     */
    public String getVorname() {
        return vorname;
    }

    /**
     * Gibt den BMI (Body-Mass-Index) der Person zurück.
     *
     * @return Der BMI der Person.
     */
    public float getBMI() {
        return BMI;
    }

    /**
     * Überschriebene Methode zur Erstellung einer String-Repräsentation der Info_BMI.
     *
     * @return Eine String-Repräsentation der Form "Nachname: ..., Vorname: ..., BMI: ...".
     */
    @Override
    public String toString() {
        return "Nachname: " + nachname + ", Vorname: " + vorname + ", BMI: " + BMI;
    }

  
}