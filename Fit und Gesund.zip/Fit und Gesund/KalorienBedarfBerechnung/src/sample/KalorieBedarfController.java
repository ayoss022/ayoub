package sample;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Controller-Klasse für die Berechnung und Verwaltung des Kalorienbedarfs.
 */
public class KalorieBedarfController {

    @FXML
    private TextField alterInputField;
    @FXML
    private TextField nachnameInputField;
    @FXML
    private TextField vornameInputField;
    @FXML
    private TextField geschlechtInputfield;
    @FXML
    private TextField taetigkeitsLevelInputfield;
    @FXML
    private TextField groesseInputField;
    @FXML
    private TextField gewichtInputField;
    @FXML
    private Label KalorienOutputLabel;

    // Modell zur Berechnung des Kalorienbedarfs
    private KalorieBedarfModel calorieBedarfModel = new KalorieBedarfModel();
    private Stage primaryStage;

    // Liste zum Speichern der gespeicherten Informationen
    private List<Info> savedInfoList = new ArrayList<>();


    /**
     * Setter für die Primärbühne.
     *
     * @param primaryStage Die Hauptbühne der Anwendung.
     */
    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    /**
     * Überprüft, ob das gegebene Info-Objekt bereits in der savedInfoList existiert.
     *
     * @param info Das Info-Objekt, das überprüft werden soll.
     * @return true, wenn die Info bereits existiert; false sonst.
     */
    private boolean isInfoDuplicate(Info info) {
        for (Info savedInfo : savedInfoList) {
            if (savedInfo.getNachname().equals(info.getNachname())
                    && savedInfo.getVorname().equals(info.getVorname())
                    && savedInfo.getCalorieNeeds() == info.getCalorieNeeds()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Handhabt die Berechnung des Kalorienbedarfs, wenn der Benutzer auf die Schaltfläche "Berechnen" klickt.
     *
     * @param actionEvent Das ausgelöste Ereignis.
     */
    @FXML
    public void handleKalorienBerechnung(ActionEvent actionEvent) {
        try {
            // Parsen der Eingaben aus den Textfeldern
            int age = Integer.parseInt(alterInputField.getText());
            String geschlecht = geschlechtInputfield.getText();
            float weight = Float.parseFloat(gewichtInputField.getText());
            float height = Float.parseFloat(groesseInputField.getText());
            float activityLevel = Float.parseFloat(taetigkeitsLevelInputfield.getText());

            // Setzen der Werte im Modell
            calorieBedarfModel.setAlter(age);
            calorieBedarfModel.setGeschlecht(geschlecht);
            calorieBedarfModel.setGewicht(weight);
            calorieBedarfModel.setGroesse(height);
            calorieBedarfModel.setTaetigkeitsLevel(activityLevel);

            // Berechnung des Kalorienbedarfs und Aktualisierung des Ausgabelabels
            float calorieNeeds = calorieBedarfModel.calculateCalorieNeeds();
            KalorienOutputLabel.setText(String.format("%.2f", calorieNeeds));
        } catch (NumberFormatException e) {
            // Handhabung ungültiger Eingaben
            KalorienOutputLabel.setText("Ungültige Eingabe");
        }
    }

    /**
     * Handhabt das Speichern der Benutzereingaben.
     *
     * @param actionEvent Das ausgelöste Ereignis.
     */
    @FXML
    private void handleSave(ActionEvent actionEvent) {
        // Eingaben aus den Textfeldern abrufen
        String nachname = nachnameInputField.getText();
        String vorname = vornameInputField.getText();
        String alter = alterInputField.getText();
        String geschlecht = geschlechtInputfield.getText();
        String activityLevel = taetigkeitsLevelInputfield.getText();
        String groesse = groesseInputField.getText();
        String gewicht = gewichtInputField.getText();

        // Überprüfen, ob ein Feld leer ist
        if (nachname.isEmpty() || vorname.isEmpty() || alter.isEmpty() || geschlecht.isEmpty() ||
                activityLevel.isEmpty() || groesse.isEmpty() || gewicht.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warnung");
            alert.setHeaderText(null);
            alert.setContentText("Keine Infos sind gespeichert. Bitte füllen Sie alle Felder aus.");
            alert.showAndWait();
            return;
        }

        try {
            // Berechnung des Kalorienbedarfs
            float calorieNeeds = calorieBedarfModel.calculateCalorieNeeds();

            // Erstellen eines neuen Info-Objekts
            Info info = new Info(nachname, vorname, calorieNeeds);

            // Überprüfen, ob die Info bereits existiert, falls nicht, zur Liste hinzufügen
            if (!isInfoDuplicate(info)) {
                savedInfoList.add(info);
            } else {
                // Aktualisieren des vorhandenen Eintrags
                for (Info savedInfo : savedInfoList) {
                    if (savedInfo.getNachname().equals(info.getNachname())
                            && savedInfo.getVorname().equals(info.getVorname())) {
                        savedInfoList.remove(savedInfo);
                        savedInfoList.add(info);
                        break;
                    }
                }
            }

            // Laden und Anzeigen der gespeicherten Informationsansicht
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("SavedInfoView.fxml"));
                Parent root = loader.load();

                SavedInfoController savedInfoController = loader.getController();
                savedInfoController.setPrimaryStage(primaryStage);
                savedInfoController.setPreviousScene(primaryStage.getScene());
                savedInfoController.setKalorieBedarfController(this);

                // Hinzufügen aller gespeicherten Infos zum Controller
                savedInfoController.clearInfoItems();
                for (Info savedInfo : savedInfoList) {
                    savedInfoController.addInfoItem(savedInfo);
                }

                Scene scene = new Scene(root, 800, 600);
                primaryStage.setScene(scene);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (NumberFormatException e) {
            // Handhabung ungültiger Eingaben
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warnung");
            alert.setHeaderText(null);
            alert.setContentText("Bitte geben Sie gültige Werte für alle Felder ein.");
            alert.showAndWait();
        }
    }

    /**
     * Entfernt ein Info-Objekt aus der gespeicherten Liste.
     *
     * @param info Das Info-Objekt, das entfernt werden soll.
     */
    public void removeInfo(Info info) {
        savedInfoList.remove(info);
    }

    /**
     * Lädt gespeicherte Infoos in die Eingabefelder.
     *
     * @param info Das Info-Objekt, dessen Werte geladen werden sollen.
     */
    public void loadInfoToFields(Info info) {
        nachnameInputField.setText(info.getNachname());
        vornameInputField.setText(info.getVorname());
        // Hinweis: Es wird angenommen, dass Alter, Geschlecht, Aktivitätslevel, Größe und Gewicht aus dem Info-Objekt abrufbar sind
        // Sie müssen dies möglicherweise anpassen, wenn Ihre Info-Klasse nicht alle diese Daten enthält
        alterInputField.setText(String.valueOf(calorieBedarfModel.getAlter()));
        geschlechtInputfield.setText(calorieBedarfModel.getGeschlecht());
        taetigkeitsLevelInputfield.setText(String.valueOf(calorieBedarfModel.getTaetigkeitsLevel()));
        groesseInputField.setText(String.valueOf(calorieBedarfModel.getGroesse()));
        gewichtInputField.setText(String.valueOf(calorieBedarfModel.getGewicht()));
    }

     /**
     * Handhabt das Anzeigen der Diagrammansicht.
     *
     * @throws IOException Wennn ein Fehler beim Laden der ChartView.fxml auftritt.
     */
    @FXML
    private void handleShowChart() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ChartView.fxml"));
        Parent root = loader.load();

        ChartController chartController = loader.getController();
        chartController.setSavedInfoList(savedInfoList);

        Stage stage = new Stage();
        stage.setTitle("Kalorienbedarf Diagramm");
        stage.setScene(new Scene(root, 800, 600));
        stage.show();
    }

    /**
     * Handhabt das Zurückkehren zur Startseite.
     *
     * @param actionEvent Das ausgelöste Ereignis.
     */
    @FXML
    private void handleBack(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("StartseiteView.fxml"));
            Parent root = loader.load();

            StartseiteController controller = loader.getController();
            controller.setPrimaryStage(primaryStage);

            Scene scene = new Scene(root, 800, 600);
            primaryStage.setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Handhabt das Öffnen eines neuen Fensters mit einem Bild basierend auf dem Kalorienbedarf
    @FXML
    private void openNewWindow() {
        // Eingaben aus den Textfeldern abrufen
        String nachname = nachnameInputField.getText();
        String vorname = vornameInputField.getText();
        String alter = alterInputField.getText();
        String geschlecht = geschlechtInputfield.getText();
        String activityLevel = taetigkeitsLevelInputfield.getText();
        String groesse = groesseInputField.getText();
        String gewicht = gewichtInputField.getText();

        // Überprüfen, ob ein Feld leer ist
        if (nachname.isEmpty() || vorname.isEmpty() || alter.isEmpty() || geschlecht.isEmpty() ||
                activityLevel.isEmpty() || groesse.isEmpty() || gewicht.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warnung");
            alert.setHeaderText(null);
            alert.setContentText("Keine Infos sind gespeichert. Bitte füllen Sie alle Felder aus.");
            alert.showAndWait();
            return;
        }
        try {
            Stage stage = new Stage();

            // Berechnung des Kalorienbedarfs
            float calorieNeeds = calorieBedarfModel.calculateCalorieNeeds();
            System.out.println("Calorie Needs: " + calorieNeeds); // Debugging

            // Auswahl des Bildes basierend auf dem Kalorienbedarf
            String imageFile = null;

            if (calorieNeeds >= 1000 && calorieNeeds < 1500) {
                imageFile = "images/image1.png";
            } else if (calorieNeeds >= 1500 && calorieNeeds < 2000) {
                imageFile = "images/image2.png";
            } else if (calorieNeeds >= 2000 && calorieNeeds < 2500) {
                imageFile = "images/image3.png";
            } else if (calorieNeeds >= 2500 && calorieNeeds < 3000) {
                imageFile = "images/image4.png";
            } else if (calorieNeeds >= 3000 && calorieNeeds < 3500) {
                imageFile = "images/image5.png";
            } else if (calorieNeeds >= 3500 && calorieNeeds < 4000) {
                imageFile = "images/image6.png";
            } else {
                imageFile = "images/Ausnahme.png";
            }

            System.out.println("Loading Image file: " + imageFile);

            // Laden und Anzeigen des Bildes in einem neuen Fenster
            Image image = new Image(getClass().getResourceAsStream("/" + imageFile));
            ImageView imageView = new ImageView(image);

            imageView.setFitWidth(600);
            imageView.setFitHeight(400);
            imageView.setPreserveRatio(true);

            StackPane root = new StackPane(imageView);

            Scene scene = new Scene(root, 600, 400);

            stage.setScene(scene);
            stage.setTitle("Neues Fenster");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}










