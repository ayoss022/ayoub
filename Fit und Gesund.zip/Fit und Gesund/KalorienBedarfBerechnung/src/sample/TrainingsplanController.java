package sample;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
/**
 * Controller-Klasse für die Trainingsplan-Ansicht.
 * Verwaltet die Anzeige verschiedener Trainingspläne über Bilder in einem separaten Fenster.
 */
public class TrainingsplanController {

    // Buttons für die verschiedenen Trainingspläne
    @FXML private Button Hamstrings;
    @FXML private Button Shoulders;
    @FXML private Button Traps;
    @FXML private Button Legs;
    @FXML private Button Chest;
    @FXML private Button Abs;
    @FXML private Button Biceps;
    @FXML private Button Triceps;
    @FXML private Button Lowerback;
    @FXML private Button Claves;
    @FXML private Button Back;
    @FXML private Button Glutes;
    /**
     * Methode zum Anzeigen des Trainingsplans für Hamstrings.
     * Öffnet ein neues Fenster und zeigt das Bild und den Titel des Trainingsplans an.
     */
    // Methode zum Anzeigen des Trainingsplans für Hamstrings
    @FXML
    private void showHamstringsPlan() {
        showPlan("images/Hamstrings.jpeg", "Program of Back and Hamstrings");
    }

    // Methode zum Anzeigen des Trainingsplans für Shoulders
    /**
     * Methode zum Anzeigen des Trainingsplans für Shoulders.
     * Öffnet ein neues Fenster und zeigt das Bild und den Titel des Trainingsplans an.
     */
    @FXML
    private void showShouldersPlan() {
        showPlan("images/Shoulders.jpg", "Program of Shoulders");
    }

    // Methode zum Anzeigen des Trainingsplans für Traps

    /**
     * Methode zum Anzeigen des Trainingsplans für Traps.
     * Öffnet ein neues Fenster und zeigt das Bild und den Titel des Trainingsplans an.
     */
    @FXML
    private void showTrapsPlan() {
        showPlan("images/Traps.jpeg", "Program of Traps");
    }

    // Methode zum Anzeigen des Trainingsplans für Legs
    /**
     * Methode zum Anzeigen des Trainingsplans für Legs.
     * Öffnet ein neues Fenster und zeigt das Bild und den Titel des Trainingsplans an.
     */
    @FXML
    private void showLegsPlan() {
        showPlan("images/Legs.jpg", "Program of Legs");
    }

    // Methode zum Anzeigen des Trainingsplans für Chest

    /**
     * Methode zum Anzeigen des Trainingsplans für Chest.
     * Öffnet ein neues Fenster und zeigt das Bild und den Titel des Trainingsplans an.
     */
    @FXML
    private void showChestsPlan() {
        showPlan("images/Chest.jpeg", "Program of Chest");
    }

    // Methode zum Anzeigen des Trainingsplans für Abs
    /**
     * Methode zum Anzeigen des Trainingsplans für Abs.
     * Öffnet ein neues Fenster und zeigt das Bild und den Titel des Trainingsplans an.
     */
    @FXML
    private void showAbsPlan() {
        showPlan("images/Abs.jpeg", "Program of Abs");
    }

    // Methode zum Anzeigen des Trainingsplans für Biceps
    /**
     * Methode zum Anzeigen des Trainingsplans für Biceps.
     * Öffnet ein neues Fenster und zeigt das Bild und den Titel des Trainingsplans an.
     */

    @FXML
    private void showBicepsPlan() {
        showPlan("images/Biceps.jpeg", "Program of Biceps");
    }

    // Methode zum Anzeigen des Trainingsplans für Triceps
    /**
     * Methode zum Anzeigen des Trainingsplans für Triceps.
     * Öffnet ein neues Fenster und zeigt das Bild und den Titel des Trainingsplans an.
     */
    @FXML
    private void showTricepsPlan() {
        showPlan("images/triceps.jpeg", "Program of Triceps");
    }

    // Methode zum Anzeigen des Trainingsplans für Lowerback
    /**
     * Methode zum Anzeigen des Trainingsplans für Lowerback.
     * Öffnet ein neues Fenster und zeigt das Bild und den Titel des Trainingsplans an.
     */
    @FXML
    private void showLowerbackPlan() {
        showPlan("images/Lowerback.jpeg", "Program of Lowerback");
    }

    // Methode zum Anzeigen des Trainingsplans für Claves
    /**
     * Methode zum Anzeigen des Trainingsplans für Back.
     * Öffnet ein neues Fenster und zeigt das Bild und den Titel des Trainingsplans an.
     */
    @FXML
    private void showClavesPlan() {
        showPlan("images/claves.jpeg", "Program of Chest and Clave");
    }

    // Methode zum Anzeigen des Trainingsplans für Back
    /**
     * Methode zum Anzeigen des Trainingsplans für Glutes.
     * Öffnet ein neues Fenster und zeigt das Bild und den Titel des Trainingsplans an.
     */
    @FXML
    private void showBackPlan() {
        showPlan("images/back.jpeg", "Program of Back");
    }

    // Methode zum Anzeigen des Trainingsplans für Glutes
    /**
     * Methode zum Anzeigen des Trainingsplans für Glutes.
     * Öffnet ein neues Fenster und zeigt das Bild und den Titel des Trainingsplans an.
     */
    @FXML
    private void showGlutesPlan() {
        showPlan("images/glutes.png", "Program of Glutes");
    }

    // Private Hilfsmethode zum Anzeigen eines Trainingsplans in einem neuen Fenster
    /**
     * Private Hilfsmethode zum Anzeigen eines Trainingsplans in einem neuen Fenster.
     *
     * @param imagePath Der Pfad zur Bilddatei des Trainingsplans.
     * @param title Der Titel des Trainingsplans.
     */

    private void showPlan(String imagePath, String title) {
        try {
            // Erstellen eines neuen Fensters (Stage)
            Stage stage = new Stage();

            // Laden des Bildes aus dem angegebenen Pfad
            Image image = new Image(getClass().getResourceAsStream("/" + imagePath));

            // Erstellen einer ImageView für das Bild mit bestimmten Dimensionen und Eigenschaften
            ImageView imageView = new ImageView(image);
            imageView.setFitWidth(600);
            imageView.setFitHeight(800);
            imageView.setPreserveRatio(true);

            // Erstellen einer StackPane als Wurzelelement für die Szene und Hinzufügen der ImageView
            StackPane root = new StackPane(imageView);

            // Erstellen einer neuen Szene mit der StackPane als Wurzelelement
            Scene scene = new Scene(root, 600, 800);

            // Setzen des Titels für das Fenster und Anzeigen des Fensters
            stage.setScene(scene);
            stage.setTitle(title);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}