package sample;

import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;

import java.util.List;



/**
 * Controller-Klasse für das Diagramm (Chart), das Informationen visualisiert.
 */


public class ChartController {

    @FXML
    private BarChart<String, Number> barChart;

    private List<Info> savedInfoList;

    /**
     * Setzt die Liste der gespeicherten Informationen und initialisiert das Diagramm.
     *
     * @param savedInfoList Die Liste der gespeicherten Informationen, die im Diagramm angezeigt werden sollen.
     */
    public void setSavedInfoList(List<Info> savedInfoList) {
        this.savedInfoList = savedInfoList;
        initializeChart();
    }

    /**
     * Private Methode zur Initialisierung des Diagramms.
     * Erstellt eine Serie basierend auf den gespeicherten Informationen.
     * Jeder Datenpunkt repräsentiert einen Eintrag in der Liste mit Vorname + Nachname als Label und Kalorienbedarf als Wert.
     */
    private void initializeChart() {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        for (Info info : savedInfoList) {
            // Für jede Info einen Datenpunkt zur Serie hinzufügen (Vorname + Nachname als Label, Kalorienbedarf als Wert)
            series.getData().add(new XYChart.Data<>(info.getVorname() + " " + info.getNachname(), info.getCalorieNeeds()));
        }

        // Serie zum Diagramm hinzufügen
        barChart.getData().add(series);
    }
}