package sample;

/**
 * Modellklasse zur Berechnung des Kalorienbedarfs basierend auf den Benutzereingaben.
 */
public class KalorieBedarfModel {
    private int alter;
    private String geschlecht;
    private float gewicht;
    private float groesse;
    private float taetigkeitsLevel;


    /**
     * Setzt das Alter des Benutzers.
     *
     * @param alter Das Alter des Benutzers.
     */
    public void setAlter(int alter) {
        this.alter = alter;
    }
    /**
     * Setzt das Geschlecht des Benutzers.
     *
     * @param geschlecht Das Geschlecht des Benutzers (männlich oder weiblich).
     */
    public void setGeschlecht(String geschlecht) {
        this.geschlecht = geschlecht;
    }
    /**
     * Setzt das Gewicht des Benutzers.
     *
     * @param gewicht Das Gewicht des Benutzers in Kilogramm.
     */
    public void setGewicht(float gewicht) {
        this.gewicht = gewicht;
    }
    /**
     * Setzt die Größe des Benutzers.
     *
     * @param groesse Die Größe des Benutzers in Metern.
     */
    public void setGroesse(float groesse) {
        this.groesse = groesse;
    }
    /**
     * Setzt das Tätigkeitslevel des Benutzers.
     *
     * @param taetigkeitsLevel Das Tätigkeitslevel des Benutzers (1.2 - 2.0).
     */
    public void setTaetigkeitsLevel(float taetigkeitsLevel) {
        this.taetigkeitsLevel = taetigkeitsLevel;
    }
    /**
     * Gibt das Alter des Benutzers zurück.
     *
     * @return Das Alter des Benutzers.
     */
    public int getAlter() {
        return alter;
    }
    /**
     * Gibt das Geschlecht des Benutzers zurück.
     *
     * @return Das Geschlecht des Benutzers.
     */
    public String getGeschlecht() {
        return geschlecht;
    }
    /**
     * Gibt das Gewicht des Benutzers zurück.
     *
     * @return Das Gewicht des Benutzers.
     */
    public float getGewicht() {
        return gewicht;
    }
    /**
     * Gibt die Größe des Benutzers zurück.
     *
     * @return Die Größe des Benutzers.
     */
    public float getGroesse() {
        return groesse;
    }
    /**
     * Gibt das Tätigkeitslevel des Benutzers zurück.
     *
     * @return Das Tätigkeitslevel des Benutzers.
     */
    public float getTaetigkeitsLevel() {
        return taetigkeitsLevel;
    }

    /**
     * Berechnet den Kalorienbedarf des Benutzers basierend auf den gesetzten Werten.
     *
     * @return Der berechnete Kalorienbedarf des Benutzers.
     */
    public float calculateCalorieNeeds() {

        // Grundumsatzberechnung basierend auf Geschlecht
        float grundumsatz=0;
        if (geschlecht.equalsIgnoreCase("male")) {
            grundumsatz = (float) (66.47 + (13.7 * gewicht) + (5 * groesse) - (6.8 * alter));
        } else if (geschlecht.equalsIgnoreCase("female")){
            grundumsatz = (float) (655.1 + (9.6 * gewicht) + (1.8 * groesse) - (4.7 * alter));
        }

        // Endgültiger Kalorienbedarf unter Berücksichtigung des Tätigkeitslevels
        return grundumsatz * taetigkeitsLevel;
    }


}
