package sample;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

import java.io.IOException;

/**
 * Controller-Klasse für die Startseite der Anwendung.
 * Verwaltet die Navigation zu verschiedenen Ansichten und das Beenden der Anwendung.
 */
public class StartseiteController {
    private Stage primaryStage;

    // Methode zum Setzen der Hauptbühne (primary stage)
    /**
     * Methode zum Setzen der Hauptbühne (primary stage) dieser Controller-Klasse.
     *
     * @param primaryStage Die Hauptbühne der Anwendung.
     */
    public void setPrimaryStage(Stage primaryStage) {

        this.primaryStage = primaryStage;
    }

    // Methode zum Wechseln zur BMI-Rechner Ansicht
    /**
     * Methode zum Wechseln zur BMI-Rechner Ansicht.
     * Lädt die entsprechende FXML-Datei, setzt die Hauptbühne und den BMIController.
     *
     * @throws IOException Falls die FXML-Datei nicht geladen werden kann.
     */
    @FXML
    private void switchToBMIRechner() throws Exception {
        // Laden der FXML-Datei für die BMI-Ansicht
        FXMLLoader loader = new FXMLLoader(getClass().getResource("BMIView.fxml"));
        Parent root = loader.load();

        // Zugriff auf den BMIController, um die Hauptbühne zu setzen
        BMIController bmiController = loader.getController();
        bmiController.setPrimaryStage(primaryStage);

        // Erstellen einer neuen Szene und Setzen auf der Hauptbühne
        Scene scene = new Scene(root, 800, 600);
        primaryStage.setScene(scene);
    }

    // Methode zum Wechseln zur Kalorienbedarf Ansicht
    /**
     * Methode zum Wechseln zur Kalorienbedarf .
     * Lädt die entsprechende FXML-Datei, setzt die Hauptbühne und den KalorieBedarfController.
     *
     * @throws IOException Falls die FXML-Datei nicht geladen werden kann.
     */
    @FXML
    private void switchToKalorieBedarf() throws Exception {
        // Laden der FXML-Datei für die Kalorienbedarf Ansicht
        FXMLLoader loader = new FXMLLoader(getClass().getResource("KalorieBedarfView.fxml"));
        Parent root = loader.load();

        // Zugriff auf den KalorieBedarfController, um die Hauptbühne zu setzen
        KalorieBedarfController kalorieController = loader.getController();
        kalorieController.setPrimaryStage(primaryStage);

        // Erstellen einer neuen Szene und Setzen auf der Hauptbühne
        Scene scene = new Scene(root, 800, 700);
        primaryStage.setScene(scene);
    }

    // Methode zum Behandeln des Button-Drucks zum Beenden der Anwendung

    /**
     * Methode zum Behandeln des Button-Drucks zum Beenden der Anwendung.
     *
     * @param actionEvent Das ActionEvent des Button-Drucks.
     */
    @FXML
    private void handleExitButtonPress(ActionEvent actionEvent) {
        Platform.exit();
    }

    // Methode zum Öffnen der Trainingsplan Ansicht in einem separaten Fenster
    /**
     * Methode zum Öffnen der Trainingsplan Ansicht in einem separaten Fenster.
     * Lädt die entsprechende FXML-Datei und erstellt ein neues Fenster (Stage) für den Trainingsplan.
     *
     * @throws IOException Falls die FXML-Datei nicht geladen werden kann.
     */
    @FXML
    private void openTrainingPlan() throws IOException {
        // Laden der FXML-Datei für die Trainingsplan Ansicht
        FXMLLoader loader = new FXMLLoader(getClass().getResource("TrainingsPlanView.fxml"));
        Parent root = loader.load();

        // Erstellen einer neuen Szene und eines neuen Fensters (Stage) für den Trainingsplan
        Scene trainingPlanScene = new Scene(root, 800, 600);
        Stage trainingPlanStage = new Stage();
        trainingPlanStage.setScene(trainingPlanScene);
        trainingPlanStage.setTitle("Trainingspläne");
        trainingPlanStage.show();
    }
}