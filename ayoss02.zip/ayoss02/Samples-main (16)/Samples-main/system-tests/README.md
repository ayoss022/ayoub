# System tests

This module contains junit tests that verify the samples functionality.
